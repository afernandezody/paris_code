#! /bin/bash
#set -x


chmod +x run-speed-test.sh	  
./run-speed-test.sh 1


