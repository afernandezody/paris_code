#!/bin/bash
#set -x

./run_one_test.sh 0.05

cp raindrop-E-k2.png ../Testreport


