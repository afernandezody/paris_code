#!/bin/bash
#set -x

./run-2dtest.sh 1 1e-4 16 F 1e-4
