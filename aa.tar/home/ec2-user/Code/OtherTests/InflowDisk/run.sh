#!/bin/bash
#set -x

./run-2dtest.sh 1 0.5e-4 16 F 1.1e-2
