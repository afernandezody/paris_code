#!/bin/sh

rm -fR *~ *.tmp tmp* */*.tmp */*~ */*.aux */*.log */*.bbl */*.blg */*.dvi
