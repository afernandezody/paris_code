#!/bin/bash
#set -x

./run_one_test.sh 32 2 0.01 5d-6 F
