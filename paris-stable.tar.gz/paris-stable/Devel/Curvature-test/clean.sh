/bin/rm -fr curvature-* *~ testinput-* *.tmp input inputvof tmpout out testinput curvature.pdf
