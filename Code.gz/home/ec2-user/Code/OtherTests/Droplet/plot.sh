#!/bin/bash
#set -x

cat plot.gp | gnuplot 
