#! /bin/bash

gnuplot <<EOF
load "plot.gp"
EOF
